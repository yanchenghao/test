import error_log
from cool_start import start_cool
from cool_start import dfdf
from cool_start import sdsd
error_log.monkey_errlog()
# dfdf.start_clear1()
# sdsd.start_clear1()